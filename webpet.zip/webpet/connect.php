<?php 
    $con = mysqli_connect("localhost","root","","B1809263_Quanlydathang");
    if (mysqli_connect_errno()){
        die("Kết nối cơ sở dữ liệu thất bại: ".mysqli_connect_error());
    };    
?>